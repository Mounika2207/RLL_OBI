export class Book
{
	id: number=0;
    author: string='';
    name: string='';
    price: number=0;
    category: string='';
    status: boolean=true;
}