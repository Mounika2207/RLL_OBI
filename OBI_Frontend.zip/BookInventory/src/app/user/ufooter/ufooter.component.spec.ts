import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UfooterComponent } from './ufooter.component';

describe('UfooterComponent', () => {
  let component: UfooterComponent;
  let fixture: ComponentFixture<UfooterComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [UfooterComponent]
    });
    fixture = TestBed.createComponent(UfooterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
