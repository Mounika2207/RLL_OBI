import { Component } from '@angular/core';
import { ApiuserService } from 'src/app/services/apiuser.service';
import { ActivatedRoute, Router } from '@angular/router';
import { User } from 'src/app/User';
@Component({
  selector: 'app-changepassword',
  templateUrl: './changepassword.component.html',
  styleUrls: ['./changepassword.component.css']
})
export class ChangepasswordComponent {

  
  email: string = '';
  newPassword: string = '';
  userId: number = 0; // Initialize the user ID
  userData:any;
  currentPassword: string = ''; 

  constructor(private apiUserService: ApiuserService, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.userId = +params['id']; 
      console.log('User ID:', this.userId);

      this.apiUserService.getUserByID(this.userId).subscribe(
        (userData: any) => { 
          console.log('User data:', userData);
          this.userData=userData;
          if (userData.email) {
            this.email = userData.email;
          } else {
            console.error('User data format mismatch');
          }
        },
        (error) => {
          console.error('Error fetching user data', error);
        }
      );
    });
  }

  changePassword() {

    if (this.email !== '' && this.userId !== 0) {
      // Check if the entered email matches the current user's email
      if (this.email === this.userData.email) {
        if(this.currentPassword===this.userData.password){
          // Proceed with changing the password
          this.apiUserService.changePassword(this.email, this.newPassword)
            .subscribe(
              response => {
                console.log('Password changed successfully', response);
                alert("Password changed successfully");
              },
              error => {
                console.error('Password change failed', error);
                alert("Password changed failed");
              }
            );
        }else {
          console.error('Entered current password does not match the user\'s current password');
          alert("Entered current password does not match the user's current password");
        }
      } 
      else {
        console.error('Entered email does not match the current user\'s email');
        alert("Entered email does not match the current user's email")
      }
    }
     else {
      console.error('Email and User ID cannot be empty');
      alert("Email cannot be empty")
    }

  }
}