import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserBooklistComponent } from './user-booklist/user-booklist.component';
import { UserBookratingComponent } from './user-bookrating/user-bookrating.component';
import { UserDashboardComponent } from './user-dashboard/user-dashboard.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { UserprofileComponent } from './userprofile/userprofile.component';
import { UserprofileeditComponent } from './userprofileedit/userprofileedit.component';
import { UserRegisterComponent } from './user-register/user-register.component';
import { UheaderComponent } from './uheader/uheader.component';
import { UfooterComponent } from './ufooter/ufooter.component';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import {MatTableModule} from '@angular/material/table';
import {MatPaginatorModule} from '@angular/material/paginator';
import {MatSortModule} from '@angular/material/sort';
import { MatInputModule} from '@angular/material/input';
import { MatFormFieldModule } from "@angular/material/form-field";
import { ChangepasswordComponent } from './changepassword/changepassword.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    UserBooklistComponent,
    UserBookratingComponent,
    UserDashboardComponent,
    UserLoginComponent,
    UserprofileComponent,
    UserprofileeditComponent,
    UserRegisterComponent,
    UheaderComponent,
    UfooterComponent,
    ChangepasswordComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule, 
    HttpClientModule,
    MatSortModule,
    MatFormFieldModule,
    MatInputModule,
    MatPaginatorModule,
    MatTableModule,
    FormsModule
  ]
})
export class UserModule { }
