import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-afooter',
  templateUrl: './admin-afooter.component.html',
  styleUrls: ['./admin-afooter.component.css']
})
export class AdminAfooterComponent {

}
