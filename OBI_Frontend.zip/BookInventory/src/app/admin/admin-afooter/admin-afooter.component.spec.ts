import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminAfooterComponent } from './admin-afooter.component';

describe('AdminAfooterComponent', () => {
  let component: AdminAfooterComponent;
  let fixture: ComponentFixture<AdminAfooterComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AdminAfooterComponent]
    });
    fixture = TestBed.createComponent(AdminAfooterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
