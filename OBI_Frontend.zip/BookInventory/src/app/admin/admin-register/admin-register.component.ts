import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiadminService } from 'src/app/services/apiadmin.service';

@Component({
  selector: 'app-admin-register',
  templateUrl: './admin-register.component.html',
  styleUrls: ['./admin-register.component.css']
})
export class AdminRegisterComponent {
  adminForm!: FormGroup;

  constructor(
    private formBuilder: FormBuilder,
    private apiadminService: ApiadminService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.adminForm = this.formBuilder.group({
      username: '',
      password: ''
    });
  }

  onSubmit() {
    const formData = this.adminForm.value;
    this.apiadminService.addAdmin(formData).subscribe(
      (response) => {
        console.log('Admin registered successfully:', response);
        alert(" Registred Successfully.");
        this.router.navigate(['/adminlogin']);
      },
      (error) => {
        console.error('Error registering admin:', error);
      }
    );
  }
}