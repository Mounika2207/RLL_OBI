import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiadminService } from 'src/app/services/apiadmin.service';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {
 
  auname!:string;
  apass!:string;
  invalid:string = "";

  constructor(private router: Router,private service: ApiadminService) { }

  aLogin = new FormGroup({
    ausername: new FormControl(''),
    apassword: new FormControl(''),
  });


  loginAdmin(formValue: any) {
    if (this.aLogin.valid) {
      const { ausername, apassword } = formValue;

      this.service.adminLogin({ username: ausername, password: apassword }).subscribe(
        (adminResponse) => {
          if (adminResponse !== null) {
            // Login successful
            sessionStorage.setItem('adminusername', ausername);
            this.router.navigate(['/admindash']);
          } else {
            // Invalid credentials
            this.invalid = "Invalid Username or Password";
          }
        },
        (error) => {
          console.error('Error during login:', error);
          this.invalid = "An error occurred during login";
        }
      );
    }
  }
  


  isUserLoggedIn(){
    let user = sessionStorage.getItem('adminusername');
    console.log(!(user === null));
    return !(user === null);
  }

  adreg(){
    this.router.navigate(['/adminregister']);
  }

  ngOnInit(): void {
  }


}