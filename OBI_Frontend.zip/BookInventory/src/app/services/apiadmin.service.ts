import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class ApiadminService {

  constructor(private http: HttpClient) {}
   
  adminLogin(data3:any) {
    return this.http.post(`http://localhost:8080/api/Admin/login`, data3);
  }

  addAdmin(data: any){
    return this.http.post(`http://localhost:8080/api/Admin/adminregister`, data);
  } 
 
}

