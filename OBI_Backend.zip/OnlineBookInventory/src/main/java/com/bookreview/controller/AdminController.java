package com.bookreview.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bookreview.entity.Admin;
import com.bookreview.entity.UserDetails;
import com.bookreview.service.AdminService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/Admin")
public class AdminController {

	@Autowired
	AdminService adminservice;
	

	
	 	@PostMapping("/login")
	    public Admin login(@RequestBody  Admin admin) {
	        String username = admin.getUsername();
	        String password = admin.getPassword();

	        Admin admin1 = adminservice.getAdminbyusername(username);

	        if (admin1 != null & admin1.getPassword().equals(password)) {
	            return admin1;
	        } else {
	            return null;
	        }
	    }
	 	

		@PostMapping("/adminregister")
		public Admin addAdmin(@RequestBody Admin adminuser)
		{
			Admin adminuserobj = adminservice.save(adminuser);
			return adminuserobj;
		}
	 
	@PostMapping("/changepassword")
	public Admin ChangePassword(@RequestParam("username") String username,@RequestParam("password") String password)
	{
		Admin admin=adminservice.getAdminbyusername(username);
		if(username==admin.getUsername())
			    admin.setUsername(username);
			    admin.setPassword(password);
		        adminservice.save(admin);
		        return admin;
		       
	}
}