package com.bookreview;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import com.bookreview.controller.ReviewController;
import com.bookreview.entity.Review;
import com.bookreview.service.ReviewService;
@SpringBootTest
public class ReviewTest {

    @Autowired
    private ReviewService reviewService;

    @Autowired
    private ReviewController reviewController;

    @Test
    public void testAddReview() {
        Review review = new Review();
        review.setBookname("SampleBook");
        review.setName("John");
        review.setReview("Great book!");
        review.setRating(5);

        Review addedReview = reviewController.findbyname(review);

        assertNotNull(addedReview);
        assertEquals("SampleBook", addedReview.getBookname());
    }
    @Test
    public void testAddReviewWithDifferentRatings() {
        String bookName = "SampleBook";
        String reviewerName = "John";
        String reviewText = "Great book!";

        // Test with ratings from 1 to 5
        for (int rating = 1; rating <= 5; rating++) {
            Review review = new Review();
            review.setBookname(bookName);
            review.setName(reviewerName);
            review.setReview(reviewText);
            review.setRating(rating);

            Review addedReview = reviewController.findbyname(review);

            assertNotNull(addedReview);
            assertEquals(bookName, addedReview.getBookname());
            assertEquals(reviewerName, addedReview.getName());
            assertEquals(reviewText, addedReview.getReview());
            assertEquals(rating, addedReview.getRating());
        }
    }


    @Test
    public void testGetAllReviews() {
        List<Review> reviews = reviewService.getAllreview();
        List<Review> retrievedReviews = reviewController.getAll();

        assertEquals(reviews.size(), retrievedReviews.size());

        for (Review review : reviews) {
            boolean isReviewFound = retrievedReviews.stream()
                    .anyMatch(r -> r.getBookname().equals(review.getBookname()));
            assertTrue(isReviewFound, "Review not found: " + review.getBookname());
        }
    }
}