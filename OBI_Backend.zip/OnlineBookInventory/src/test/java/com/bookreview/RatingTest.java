package com.bookreview;

public class RatingTest {

}
